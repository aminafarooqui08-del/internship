import pandas as pd

data = {
    "StudyHours":[2,3,4,5,6],
    "Marks":[50,60,65,80,90]
}

df = pd.DataFrame(data)

print("Correlation")
print(df.corr())

print("Covariance")
print(df.cov())