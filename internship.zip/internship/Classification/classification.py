import pandas as pd
from sklearn.tree import DecisionTreeClassifier

data = {
    "Marks":[35,45,60,75,90],
    "Result":[0,0,1,1,1]
}

df = pd.DataFrame(data)

X = df[["Marks"]]
y = df["Result"]

model = DecisionTreeClassifier()

model.fit(X,y)

print(model.predict([[55]]))