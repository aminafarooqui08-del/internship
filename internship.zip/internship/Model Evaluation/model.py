actual = [1, 0, 1, 1, 0, 1]
predicted = [1, 0, 1, 0, 0, 1]

correct = 0

for i in range(len(actual)):
    if actual[i] == predicted[i]:
        correct += 1

accuracy = (correct / len(actual)) * 100

print("Correct Predictions =", correct)
print("Total Predictions =", len(actual))
print("Accuracy =", accuracy, "%")