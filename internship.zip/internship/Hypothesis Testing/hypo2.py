from sklearn.datasets import load_iris
import numpy as np

iris = load_iris()

mean_value = np.mean(iris.data[:,0])

print("Sample Mean =", mean_value)

if mean_value > 5:
    print("Reject H0")
else:
    print("Accept H0")