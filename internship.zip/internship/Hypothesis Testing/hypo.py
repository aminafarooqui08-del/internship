marks = [70, 72, 75, 78, 80, 82, 85]

sample_mean = sum(marks) / len(marks)

hypothesized_mean = 70

print("Sample Mean =", sample_mean)
print("Hypothesized Mean =", hypothesized_mean)

if sample_mean > hypothesized_mean:
    print("Reject Null Hypothesis (H0)")
    print("Average marks are greater than 70")
else:
    print("Accept Null Hypothesis (H0)")
    print("Average marks are not greater than 70")