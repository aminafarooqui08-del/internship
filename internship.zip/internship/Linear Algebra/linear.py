import numpy as np

sales = np.array([[100,200],[300,400]])
profit = np.array([[10,20],[30,40]])

print("Addition")
print(sales+profit)

print("Multiplication")
print(sales.dot(profit))