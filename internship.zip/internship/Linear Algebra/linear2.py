from sklearn.datasets import load_iris
import numpy as np

iris = load_iris()

A = iris.data[:2,:2]

B = iris.data[2:4,:2]

print("Addition")
print(A+B)

print("Multiplication")
print(np.dot(A,B.T))