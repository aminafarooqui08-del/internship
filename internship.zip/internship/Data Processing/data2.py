from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler

iris = load_iris()

scaler = StandardScaler()

scaled_data = scaler.fit_transform(iris.data)

print(scaled_data[:5])