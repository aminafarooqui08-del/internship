import pandas as pd
from sklearn.preprocessing import StandardScaler

data = {
    "Age":[22,25,30,35,40],
    "Salary":[25000,30000,45000,55000,70000]
}

df = pd.DataFrame(data)

scaler = StandardScaler()

scaled = scaler.fit_transform(df)

print(scaled)