from sympy import symbols, diff

# Define variable
x = symbols('x')

# Define function
f = x**3 + 5*x + 2

# Find derivative
derivative = diff(f, x)

print("Function =", f)
print("Derivative =", derivative)