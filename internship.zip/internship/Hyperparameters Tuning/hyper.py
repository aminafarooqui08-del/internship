import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV

data = {
    "Age":[20,25,30,35,40,45],
    "Buy":[0,0,1,1,1,1]
}

df = pd.DataFrame(data)

X = df[["Age"]]
y = df["Buy"]

parameters = {
    "max_depth":[1,2,3,4]
}

grid = GridSearchCV(
    DecisionTreeClassifier(),
    parameters,
    cv=2
)

grid.fit(X,y)

print("Best Parameter")
print(grid.best_params_)