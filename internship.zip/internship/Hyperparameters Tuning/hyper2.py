from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import GridSearchCV

iris = load_iris()

params = {
    "max_depth":[2,3,4,5],
    "criterion":["gini","entropy"]
}

grid = GridSearchCV(
    DecisionTreeClassifier(),
    params,
    cv=5
)

grid.fit(iris.data, iris.target)

print("Best Parameters")
print(grid.best_params_)