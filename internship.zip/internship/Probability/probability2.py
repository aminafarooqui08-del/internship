from sklearn.datasets import load_iris
import pandas as pd

iris = load_iris()

df = pd.DataFrame(iris.data,
                  columns=iris.feature_names)

prob = len(df[df['sepal length (cm)'] > 5]) / len(df)

print("Probability =", prob)