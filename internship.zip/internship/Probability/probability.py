import random

count = 0

for i in range(1000):
    if random.randint(1,6) == 6:
        count += 1

print("Probability of 6 =", count/1000)