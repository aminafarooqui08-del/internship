import numpy as np
import matplotlib.pyplot as plt

salary = np.random.normal(50000,5000,1000)

plt.hist(salary,bins=20)
plt.title("Salary Distribution")
plt.show()