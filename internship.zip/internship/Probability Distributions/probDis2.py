from sklearn.datasets import load_iris
import matplotlib.pyplot as plt

iris = load_iris()

plt.hist(iris.data[:,0], bins=10)

plt.title("Sepal Length Distribution")

plt.show()