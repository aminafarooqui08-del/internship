import pandas as pd

data = {
    "CustomerID":range(1,101),
    "Age":range(20,120)
}

df = pd.DataFrame(data)

sample = df.sample(20)

print(sample)
print("Sample Mean:",sample["Age"].mean())