import pandas as pd

data = {
    "Name":["Ali","Sara","John","Amina","Zoya"],
    "Marks":[78,85,92,88,75]
}

df = pd.DataFrame(data)

print("Mean:",df["Marks"].mean())
print("Median:",df["Marks"].median())
print("Mode:",df["Marks"].mode()[0])
print("Maximum:",df["Marks"].max())
print("Minimum:",df["Marks"].min())