import pandas as pd

df = pd.read_csv("student_dataset_10000_rows.csv")

print(df.describe())