import pandas as pd
from sklearn.decomposition import PCA

data = {
    "Math":[90,80,85,95,70],
    "Science":[88,79,82,96,72],
    "English":[91,78,80,94,75]
}

df = pd.DataFrame(data)

pca = PCA(n_components=2)

result = pca.fit_transform(df)

print(result)