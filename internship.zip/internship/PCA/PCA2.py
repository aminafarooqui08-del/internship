from sklearn.datasets import load_iris
from sklearn.decomposition import PCA

iris = load_iris()

pca = PCA(n_components=2)

result = pca.fit_transform(iris.data)

print(result[:10])