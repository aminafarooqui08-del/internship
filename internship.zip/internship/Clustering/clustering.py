import pandas as pd
from sklearn.cluster import KMeans

data = {
    "Income":[15,20,25,80,85,90],
    "Spending":[20,25,30,75,80,85]
}

df = pd.DataFrame(data)

kmeans = KMeans(n_clusters=2)

df["Cluster"] = kmeans.fit_predict(df)

print(df)