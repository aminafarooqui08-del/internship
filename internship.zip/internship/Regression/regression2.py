from sklearn.datasets import load_iris
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

iris = load_iris()

X = iris.data[:,0:3]
y = iris.data[:,3]

X_train,X_test,y_train,y_test = train_test_split(
    X,y,test_size=0.2,random_state=42)

model = LinearRegression()

model.fit(X_train,y_train)

print(model.predict(X_test[:5]))