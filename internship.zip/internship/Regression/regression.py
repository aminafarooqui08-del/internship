import pandas as pd
from sklearn.linear_model import LinearRegression

data = {
    "Experience":[1,2,3,4,5],
    "Salary":[25000,30000,40000,50000,65000]
}

df = pd.DataFrame(data)

X = df[["Experience"]]
y = df["Salary"]

model = LinearRegression()

model.fit(X,y)

print("Predicted Salary:",model.predict([[6]]))